import React from "react";

const Wrapper = props => <main className="wrapper" {...props} />;
// console.log("in wrapper component")
// console.log(props)

export default Wrapper;
