import React from "react";
import "./TitleOnly.css";

const Title = (props) => (
    <nav className="navbar" className="Nav">
        <div className="text-center container">
            {/* <div className="text-center"> */}
                <h1 id="title" >PicMe</h1>
            {/* </div> */}
        </div>
    </nav>
);

export default Title;